<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('popup'); ?>
	##parent-placeholder-3b6fb9033a8302fc168ca0199caaba142dbc5530##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
	##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Blog Page Start Here -->
<div class="blog ptb-100  ptb-sm-60">
            <div class="container">
                <div class="main-blog">
                    <div class="row">
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\1.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">At wisi enim ad minim veniam.</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>28</span>
                                    June
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\2.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">Dt wisi enim ad minim veniam..</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>26</span>
                                    Oct
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\2.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">At wisi enim ad minim veniam.</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>18</span>
                                    Jan
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\1.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">Dt wisi enim ad minim veniam..</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>21</span>
                                    Feb
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\1.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">At wisi enim ad minim veniam.</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>19</span>
                                    Sep
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\2.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">Dt wisi enim ad minim veniam..</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>28</span>
                                    June
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\2.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">At wisi enim ad minim veniam.</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>25</span>
                                    Mar
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                        <!-- Single Blog Start -->
                        <div class="col-lg-6 col-sm-12">
                           <div class="single-latest-blog">
                               <div class="blog-img">
                                   <a href="single-blog.php"><img src="img\blog\1.jpg" alt="blog-image"></a>
                               </div>
                               <div class="blog-desc">
                                   <h4><a href="single-blog.php">Dt wisi enim ad minim veniam..</a></h4>
                                    <ul class="meta-box d-flex">
                                        <li><a href="#">By Truemart</a></li>
                                    </ul>
                                    <p>Aenean vestibulum pretium enim vitae , non commodo urna volutpat . Pellentesque vel lacus  eget est d...</p>
                                    <a class="readmore" href="single-blog.php">Read More</a>
                               </div>
                               <div class="blog-date">
                                    <span>14</span>
                                    Aug
                                </div>
                           </div>
                        </div>
                        <!-- Single Blog End -->
                    </div>
                    <!-- Row End -->
                    <div class="row">
                        <div class="col-sm-12">
                                <div class="pro-pagination">
                                    <ul class="blog-pagination">
                                        <li class="active"><a href="#">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                                    </ul>                                    
                                    <div class="product-pagination">
                                        <span class="grid-item-list">Showing 1 to 12 of 51 (5 Pages)</span>
                                    </div>
                                </div>
                                <!-- Product Pagination Info -->
                        </div>
                    </div>
                    <!-- Row End -->
                </div>
            </div>
            <!-- Container End -->
        </div>
        <!-- Blog Page End Here -->
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookair/Desktop/shop/resources/views/blog.blade.php ENDPATH**/ ?>